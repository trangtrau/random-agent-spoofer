import subprocess


def get_hardware_info():
    try:
        # Lấy HWID
        hwid = subprocess.check_output('wmic csproduct get uuid', shell=True).decode().split('\n')[1].strip()
        # Lấy ID ổ cứng
        drive_id = subprocess.check_output('wmic diskdrive get serialnumber', shell=True).decode().split('\n')[1].strip()
        return hwid, drive_id
    except Exception as e:
        return f"Error: {e}"

hwid, drive_id = get_hardware_info()
print("HWID:", hwid)
print("Drive ID:", drive_id)
