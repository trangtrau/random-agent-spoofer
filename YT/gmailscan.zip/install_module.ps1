# Khai báo danh sách các gói Python và phiên bản cần cài đặt
$pythonPackages = @(
    "beautifulsoup4==4.12.3",
    "bs4==0.0.2",
    "cachetools==5.5.0",
    "certifi==2024.8.30",
    "charset-normalizer==3.3.2",
    "comtypes==1.4.6",
    "Faker==28.1.0",
    "google-api-core==2.19.2",
    "google-api-python-client==2.143.0",
    "google-auth==2.34.0",
    "google-auth-httplib2==0.2.0",
    "google-auth-oauthlib==1.2.1",
    "googleapis-common-protos==1.65.0",
    "gspread==6.1.2",
    "httplib2==0.22.0",
    "idna==3.8",
    "numpy==2.1.0",
    "oauthlib==3.2.2",
    "pandas==2.2.2",
    "pillow==10.4.0",
    "proto-plus==1.24.0",
    "protobuf==5.28.0",
    "pyasn1==0.6.0",
    "pyasn1_modules==0.4.0",
    "PyAutoGUI==0.9.54",
    "PyGetWindow==0.0.9",
    "PyMsgBox==1.0.9",
    "pyotp==2.9.0",
    "pyparsing==3.1.4",
    "pyperclip==1.9.0",
    "PyRect==0.2.0",
    "PyScreeze==1.0.1",
    "python-dateutil==2.9.0.post0",
    "pytweening==1.2.0",
    "pytz==2024.1",
    "pywin32==306",
    "pywinauto==0.6.8",
    "requests==2.32.3",
    "requests-oauthlib==2.0.0",
    "rsa==4.9",
    "six==1.16.0",
    "soupsieve==2.6",
    "ttkbootstrap==1.10.1",
    "tzdata==2024.1",
    "uritemplate==4.1.1",
    "urllib3==2.2.2"
)

# Khai báo danh sách các gói Node.js và phiên bản cần cài đặt
$nodejsPackages = @(
    "axios@1.7.7",
    "child_process@1.0.2",
    "fs-extra@11.2.0",
    "googleapis@143.0.0",
    "luxon@3.5.0",
    "path@0.12.7",
    "puppeteer@23.2.1",
    "ffi-napi@4.0.3",
    "ref-array-napi@1.2.2"

)

# Hàm để cài đặt các gói Python sử dụng pip
function Install-PythonPackages {
    param([string[]]$Packages)
    foreach ($package in $Packages) {
        Start-Process "pip" -ArgumentList "install", $package -NoNewWindow -Wait
    }
}

# Hàm để cài đặt các gói Node.js sử dụng npm
function Install-NodejsPackages {
    param([string[]]$Packages)
    foreach ($package in $Packages) {
        Start-Process "npm" -ArgumentList "install", "-g", $package -NoNewWindow -Wait
    }
}

# Gọi hàm để cài đặt các gói
Install-PythonPackages -Packages $pythonPackages
Install-NodejsPackages -Packages $nodejsPackages
npm install axios@1.7.7 child_process@1.0.2 fs-extra@11.2.0 googleapis@143.0.0 luxon@3.5.0 path@0.12.7 puppeteer@23.2.1

